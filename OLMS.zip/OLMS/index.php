<?php

	header("location: controller/home.php?activity=dashboard");

?>