
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/navigation.css">
	</head>
	<body>
		<ul>
			<li><a href="home.php?activity=dashboard">Home</a></li>
			<li><a href="home.php?activity=register">Register</a></li>
			<li><a href="home.php?activity=adminLogin">Admin</a></li>
			<li><a href="home.php?activity=studentLogin">Student login</a></li>
			<li><a href="home.php?activity=facultyLogin">Faculty login</a></li>
			<li><a href="home.php?activity=search">Search</a></li>
		</ul>
	</body>
</html>